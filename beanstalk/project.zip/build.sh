zip -r project.zip  . -x project.zip
